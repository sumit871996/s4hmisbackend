package com.app.entities;

public enum Gender {

	MALE, FEMALE, OTHER

}
