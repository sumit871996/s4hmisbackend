package com.app.entities;

public enum DepartmentEnum {

	ORTHOPEDY, SKIN, ENT, DENTAL, NEUROLOGY, RADIOLOGY,

	RECEPTION,

	MEDICINE,

	PATHOLOGY

}
