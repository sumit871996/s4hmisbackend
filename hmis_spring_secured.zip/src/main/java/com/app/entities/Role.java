package com.app.entities;

public enum Role {
	ROLE_PATIENT,

	ROLE_DOCTOR,

	ROLE_PATHOLOGIST,

	ROLE_ADMIN,

	ROLE_RECEPTIONIST
}
