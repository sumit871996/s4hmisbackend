//package com.app.dto;
//
//import java.time.LocalDate;
//
//import com.app.entities.Bed;
//import com.app.entities.Bill;
//import com.app.entities.Employee;
//import com.app.entities.Slot;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString
//public class TreatmentPathologyUpdatableDto {
//	
//	private String testName;
//}
