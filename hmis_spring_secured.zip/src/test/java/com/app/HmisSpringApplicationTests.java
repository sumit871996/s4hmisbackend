package com.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmisSpringApplicationTests {
	
	void m1()
	{
		System.out.println("123456");
	}

	@Test
	void contextLoads() {
	}

}
